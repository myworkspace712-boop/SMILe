import { useState, useRef, useEffect } from "react";
import { CiMenuBurger } from "react-icons/ci";
// import { MdSearch } from "react-icons/md";
import { TbTruckDelivery } from "react-icons/tb";
import { MdOutlineAccountCircle, MdOutlineShoppingCart,
         MdOutlineNotifications, MdOutlinePhone,
         MdOutlinePeopleAlt, MdOutlineSettings, MdRefresh } from "react-icons/md";
import { MdArrowDropDown } from "react-icons/md";
import { createPortal } from "react-dom";
import { NAV_ITEMS, TICKER_ITEMS } from "./Data/siteData.js";
import Sidebar from "./Sidebar";

export default function Navbar() {
  const [drawerOpen, setDrawerOpen]   = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [walletSpin, setWalletSpin]   = useState(false);
  const [awb, setAwb]                 = useState("");
  const [openDropdown, setOpenDropdown] = useState(null);

  const profileRef  = useRef(null);
  const dropdownRef = useRef(null);

  /* close profile & dropdowns on outside click */
  useEffect(() => {
    const handler = (e) => {
      if (profileRef.current && !profileRef.current.contains(e.target))
        setProfileOpen(false);
      if (dropdownRef.current && !dropdownRef.current.contains(e.target))
        setOpenDropdown(null);
    };
    document.addEventListener("click", handler);
    return () => document.removeEventListener("click", handler);
  }, []);

  const handleTrack = (e) => {
    e.preventDefault();
    if (awb.trim())
      window.open(`https://shreemaruti.com/track-shipment/?awb=${encodeURIComponent(awb)}`, "_blank");
  };

  return (
    <div className="w-full font-sans">

      {/* ── Announcement ticker ─────────────────────── */}
      <div className="bg-blue-950 overflow-hidden py-1.5">
        <div className="flex animate-ticker whitespace-nowrap gap-16">
          {[...TICKER_ITEMS, ...TICKER_ITEMS].map((t, i) => (
            <span key={i} className="inline-flex items-center gap-2 text-xs text-white/70">
              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0" />
              {t}
            </span>
          ))}
        </div>
      </div>

      {/* ── Main navbar ─────────────────────────────── */}
      <nav className="sticky top-0 z-50 bg-blue-200/50 backdrop-blur-md border-b border-white/30 shadow-sm">
        <div className="px-4 sm:px-6 h-[68px] flex items-center justify-between gap-3">

          {/* Logo */}
          <a href="/" className="flex items-center gap-2 shrink-0">
            <div className="h-10 w-10 rounded-xl bg-blue-800 flex items-center justify-center">
              <span className="text-white font-display font-black text-base tracking-tighter">SM</span>
            </div>
            <div className="hidden sm:block leading-tight">
              <p className="font-display font-bold text-sm text-blue-950">Shree Maruti</p>
              <p className="text-[10px] text-blue-700 font-medium">Integrated Logistics</p>
            </div>
          </a>

          {/* Desktop nav links */}
          <div ref={dropdownRef} className="hidden lg:flex items-center gap-1">
            {NAV_ITEMS.map((item) => (
              <div key={item.key} className="relative">
                {item.children ? (
                  <>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setOpenDropdown(openDropdown === item.key ? null : item.key);
                      }}
                      className="flex items-center gap-0.5 px-3 py-2 rounded-full text-sm font-medium
                                 text-blue-950 hover:bg-white/50 hover:backdrop-blur-md
                                 transition-all duration-200 cursor-pointer"
                    >
                      {item.label}
                      <MdArrowDropDown
                        className={`w-4 h-4 transition-transform duration-200
                                    ${openDropdown === item.key ? "rotate-180" : ""}`}
                      />
                    </button>

                    {openDropdown === item.key && (
                      <div
                        className="absolute top-full left-0 mt-2 z-50 min-w-[220px]
                                   bg-white/80 backdrop-blur-xl border border-white/60
                                   rounded-2xl shadow-xl py-2 animate-fade-in-up"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {item.children.map((child) => (
                          <a
                            key={child.label}
                            href={child.href}
                            target={child.href.startsWith("http") ? "_blank" : undefined}
                            rel="noopener noreferrer"
                            onClick={() => setOpenDropdown(null)}
                            className="flex flex-col px-4 py-2.5 mx-2 my-0.5 rounded-xl
                                       hover:bg-blue-50/70 hover:backdrop-blur-md
                                       transition-all duration-150 group"
                          >
                            <span className="text-sm font-semibold text-blue-950 group-hover:text-blue-800">
                              {child.label}
                            </span>
                            {child.desc && (
                              <span className="text-[11px] text-gray-500 mt-0.5">{child.desc}</span>
                            )}
                          </a>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  <a
                    href={item.href}
                    className="px-3 py-2 rounded-full text-sm font-medium text-blue-950
                               hover:bg-white/50 hover:backdrop-blur-md
                               transition-all duration-200"
                  >
                    {item.label}
                  </a>
                )}
              </div>
            ))}
          </div>

          {/* Right side: AWB search + Track + Profile + Hamburger */}
          <div className="flex items-center gap-2 shrink-0">

            {/* AWB quick track */}
            <form
              onSubmit={handleTrack}
              className="hidden md:flex items-center gap-0 rounded-full overflow-hidden
                         border border-white/40 bg-blue-800/30 backdrop-blur-md shadow-md"
            >
              <div className="flex items-center gap-1.5 px-3 py-2">
                <TbTruckDelivery className="w-4 h-4 text-white/80 shrink-0" />
                <input
                  value={awb}
                  onChange={(e) => setAwb(e.target.value)}
                  placeholder="Enter AWB to track"
                  className="bg-transparent border-none outline-none text-white text-xs
                             placeholder:text-white/50 w-36"
                />
              </div>
              <button
                type="submit"
                className="bg-orange-500 hover:bg-orange-600 transition-colors duration-200
                           text-white text-xs font-semibold px-4 py-2 cursor-pointer"
              >
                Track
              </button>
            </form>

            {/* Ship Now CTA */}
            <a
              href="https://shreemaruti.com/ebookings/"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-1.5 px-4 py-2 rounded-full
                         bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold
                         shadow-md hover:shadow-orange-400/40 transition-all duration-200
                         hover:scale-105"
            >
              Ship Now
            </a>

            {/* Profile avatar */}
            <div
              ref={profileRef}
              onClick={(e) => { e.stopPropagation(); setProfileOpen((p) => !p); }}
              className="w-9 h-9 rounded-full bg-orange-400/80 flex items-center justify-center
                         text-white font-bold text-sm shadow-md border border-transparent
                         hover:scale-105 hover:border-white/30 hover:bg-orange-400/60
                         hover:backdrop-blur-md cursor-pointer transition-all duration-200"
            >
              A
            </div>

            {/* Hamburger — mobile */}
            <button
              onClick={(e) => { e.stopPropagation(); setDrawerOpen((p) => !p); setProfileOpen(false); }}
              className="w-9 h-9 flex items-center justify-center rounded-full
                         bg-blue-800 text-white shadow-md border border-transparent
                         hover:bg-blue-800/70 hover:border-white/30 hover:scale-105
                         transition-all duration-200 cursor-pointer"
              aria-label="Toggle menu"
            >
              <CiMenuBurger className="w-4 h-4" />
            </button>
          </div>
        </div>
      </nav>

      {/* ── Sidebar (mobile drawer) ──────────────────── */}
      <Sidebar drawerOpen={drawerOpen} setDrawerOpen={setDrawerOpen} />

      {/* ── Profile dropdown portal ──────────────────── */}
      {profileOpen &&
        createPortal(
          <div
            onClick={(e) => e.stopPropagation()}
            className="fixed top-20 right-4 z-[200] w-56
                       bg-white/70 backdrop-blur-xl shadow-xl
                       rounded-2xl py-2 border border-white/50
                       animate-fade-in-up"
          >
            <p className="text-center text-sm font-semibold text-blue-950 py-1 px-4">
              Demo for Testing (ADMIN)
            </p>

            {/* Wallet */}
            <div className="border-b border-zinc-200 mx-3 mb-1 pb-1">
              <div className="flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium text-blue-950">
                <MdOutlineAccountCircle className="w-4 h-4 text-blue-900 shrink-0" />
                <span className="flex-1">Wallet</span>
                <span className="text-xs font-semibold text-zinc-600">₹ 24,500.00</span>
                <button
                  onClick={(e) => { e.stopPropagation(); setWalletSpin(true); setTimeout(() => setWalletSpin(false), 700); }}
                  className="text-orange-400 hover:text-orange-500 transition-colors cursor-pointer"
                >
                  <MdRefresh className={`w-4 h-4 ${walletSpin ? "animate-spin-once" : ""}`} />
                </button>
              </div>
            </div>

            {[
              { Icon: MdOutlineShoppingCart, label: "Cart" },
              { Icon: MdOutlineNotifications, label: "Notifications", dot: true },
              { Icon: MdOutlinePhone, label: "Phone" },
            ].map(({ Icon, label, dot }) => (
              <div
                key={label}
                className="flex items-center gap-3 px-3 py-2.5 mx-2 my-0.5 text-sm font-medium
                           text-blue-950 hover:bg-white/60 hover:backdrop-blur-xl hover:shadow-md
                           hover:scale-[1.03] cursor-pointer transition-all duration-200 rounded-xl"
              >
                <Icon className="w-4 h-4 text-blue-900 shrink-0" />
                <span className="flex-1">{label}</span>
                {dot && <span className="w-2 h-2 rounded-full bg-red-400 shrink-0" />}
              </div>
            ))}

            <div className="border-t border-zinc-200 mt-1 pt-1">
              {[
                { Icon: MdOutlinePeopleAlt, label: "My Profile" },
                { Icon: MdOutlineSettings,  label: "Settings" },
                { Icon: MdOutlinePhone,     label: "Help & Support" },
              ].map(({ Icon, label }) => (
                <div
                  key={label}
                  className="flex items-center gap-3 px-3 py-2.5 mx-2 my-0.5 text-sm font-medium
                             text-blue-950 hover:bg-white/60 hover:backdrop-blur-xl hover:shadow-md
                             hover:scale-[1.03] cursor-pointer transition-all duration-200 rounded-xl"
                >
                  <Icon className="w-4 h-4 text-blue-900 shrink-0" />
                  <span>{label}</span>
                </div>
              ))}
            </div>

            <div className="border-t border-zinc-200 mt-1 pt-1">
              <div className="flex items-center gap-3 px-3 py-2.5 mx-2 my-0.5 text-sm font-medium
                             text-orange-600 hover:bg-orange-100/70 hover:shadow-md
                             hover:scale-[1.03] cursor-pointer transition-all duration-200 rounded-xl">
                <MdOutlineSettings className="w-4 h-4 text-orange-500 shrink-0" />
                <span>Sign Out</span>
              </div>
            </div>
          </div>,
          document.body
        )}
    </div>
  );
}
