import { FOOTER_LINKS, SOCIAL_LINKS } from "./Data/siteData.js";

// Real social icon images from shreemaruti.com
const SOCIAL_ICON_IMGS = {
  f:  "https://shreemaruti.com/wp-content/uploads/2023/08/icon-facebook.svg",
  in: "https://shreemaruti.com/wp-content/uploads/2023/08/icon-instagram.svg",
  li: "https://shreemaruti.com/wp-content/uploads/2023/08/icon-linkedin.svg",
  x:  "https://shreemaruti.com/wp-content/uploads/2023/08/icon-twitter.svg",
  yt: "https://shreemaruti.com/wp-content/uploads/2023/08/icon-youtube.svg",
};
const SOCIAL_FALLBACK = { f: "f", in: "in", li: "li", x: "𝕏", yt: "▶" };

// Real app store badge images
const APP_BADGES = {
  "Google Play": "https://shreemaruti.com/wp-content/uploads/2023/08/google-play-badge.png",
  "App Store":   "https://shreemaruti.com/wp-content/uploads/2023/08/app-store-badge.png",
};

export default function Footer() {
  return (
    <footer className="bg-zinc-900 text-white/70">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 pt-14 sm:pt-16 pb-8">

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8 sm:gap-10 mb-10 sm:mb-12">

          {/* Brand — 2 cols on lg */}
          <div className="sm:col-span-2 lg:col-span-2">
            <a href="" className="flex items-center gap-2.5 mb-4 no-underline">
              <img
                src="https://shreemaruti.com/wp-content/uploads/2023/08/smile-logo.png"
                alt="Shree Maruti"
                className="h-9 w-auto object-contain brightness-0 invert opacity-80"
                onError={(e) => {
                  e.currentTarget.style.display = "none";
                  e.currentTarget.nextElementSibling.style.display = "flex";
                }}
              />
              <div className="hidden w-10 h-10 rounded-xl bg-blue-800 items-center justify-center">
                <span className="text-white font-display font-black text-base tracking-tighter">SM</span>
              </div>
              <div>
                <p className="font-display font-bold text-white text-base leading-tight">Shree Maruti</p>
                <p className="text-[11px] text-blue-400">Integrated Logistics Limited</p>
              </div>
            </a>
            <p className="text-[13.5px] text-white/50 leading-relaxed mb-5 max-w-xs">
              India's fastest express delivery, supply chain and logistics provider.
              Proudly Made in India, Delivered to the World.
            </p>

            {/* Social icons */}
            <div className="flex gap-2 flex-wrap">
              {SOCIAL_LINKS.map(({ icon, label }) => (
                <a
                  key={label}
                  href=""
                  aria-label={label}
                  className="w-9 h-9 rounded-xl bg-white/8 border border-white/10
                             flex items-center justify-center
                             hover:bg-orange-500 hover:border-orange-500
                             transition-all duration-300 no-underline group"
                >
                  <img
                    src={SOCIAL_ICON_IMGS[icon]}
                    alt={label}
                    className="w-4 h-4 object-contain brightness-0 invert opacity-70
                               group-hover:opacity-100 transition-opacity duration-200"
                    onError={(e) => {
                      e.currentTarget.style.display = "none";
                      e.currentTarget.nextElementSibling.style.display = "block";
                    }}
                  />
                  <span className="hidden text-[11px] font-bold text-white/70">
                    {SOCIAL_FALLBACK[icon]}
                  </span>
                </a>
              ))}
            </div>

            {/* App store badges */}
            <div className="flex gap-2 mt-4 flex-wrap">
              {["Google Play", "App Store"].map((name) => (
                <a
                  key={name}
                  href=""
                  className="no-underline transition-all duration-300 hover:scale-105 active:scale-95"
                >
                  <img
                    src={APP_BADGES[name]}
                    alt={name}
                    className="h-9 w-auto object-contain opacity-80
                               hover:opacity-100 transition-opacity duration-300"
                    onError={(e) => {
                      e.currentTarget.style.display = "none";
                      e.currentTarget.nextElementSibling.style.display = "flex";
                    }}
                  />
                  <div className="hidden items-center gap-2 px-3 py-2 rounded-xl bg-white/8 border border-white/10">
                    <span className="text-[11px] font-semibold text-white">{name}</span>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Link columns — 3 cols within remaining 3 lg slots */}
          <div className="sm:col-span-2 lg:col-span-3 grid grid-cols-2 sm:grid-cols-3 gap-6 sm:gap-8">
            {Object.entries(FOOTER_LINKS).map(([heading, links]) => (
              <div key={heading}>
                <h4 className="font-display font-bold text-white text-[11px] tracking-widest uppercase mb-4">
                  {heading}
                </h4>
                <ul className="flex flex-col gap-2">
                  {links.map(({ label, badge }) => (
                    <li key={label}>
                      <a
                        href=""
                        className="text-[13px] text-white/50 hover:text-white
                                   transition-colors duration-200 no-underline
                                   inline-flex items-center gap-2"
                      >
                        {label}
                        {badge && (
                          <span className="text-[9px] font-bold bg-orange-500 text-white px-1.5 py-0.5 rounded-full">
                            {badge}
                          </span>
                        )}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}

            {/* Contact */}
            <div>
              <h4 className="font-display font-bold text-white text-[11px] tracking-widest uppercase mb-4">
                Contact Us
              </h4>
              <ul className="flex flex-col gap-3 text-[13px] text-white/50">
                <li>
                  <a href="mailto:info@shreemaruti.com"
                     className="hover:text-white transition-colors duration-200 no-underline">
                    info@shreemaruti.com
                  </a>
                </li>
                <li>
                  <a href="tel:+919712666666"
                     className="hover:text-white transition-colors duration-200 no-underline">
                    +91 9712 666 666
                  </a>
                </li>
                <li className="text-white/35 text-[11px] leading-relaxed">
                  52/A, Titanium, Opp. Prahaladnagar Garden,<br />
                  100 Ft Road, Ahmedabad — 380015
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row
                        items-center justify-between gap-4 text-center sm:text-left">
          <p className="text-[12px] text-white/30">
            © {new Date().getFullYear()} Shree Maruti Integrated Logistics Limited. All rights reserved.
          </p>
          <div className="flex flex-wrap justify-center sm:justify-end gap-4 text-[12px] text-white/30">
            {["Privacy Policy", "Terms", "ONDC Disclosure"].map((label) => (
              <a key={label} href=""
                 className="hover:text-white transition-colors duration-200 no-underline">
                {label}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
