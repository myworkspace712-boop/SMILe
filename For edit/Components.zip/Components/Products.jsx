import { MdArrowOutward } from "react-icons/md";
import { PRODUCTS } from "./Data/siteData.js";

export default function Products() {
  return (
    <section className="py-24 bg-gradient-to-b from-blue-50/60 to-white">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6">

        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1.5 rounded-full bg-orange-50 text-orange-600
                           text-xs font-bold tracking-widest uppercase mb-4">
            Our Products
          </span>
          <h2 className="font-display font-extrabold text-blue-950 text-3xl sm:text-4xl xl:text-5xl
                         leading-tight mb-4">
            From Humble Beginnings to{" "}
            <span className="text-orange-500">Global Excellence</span>
          </h2>
          <p className="text-gray-500 text-base max-w-xl mx-auto leading-relaxed">
            SMILe has been built keeping users in mind. Our dedication to attention to
            detail ensures hassle-free logistics at all times.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {PRODUCTS.map(({ tag, name, desc, href }) => (
            <a
              key={name}
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="group bg-white border border-blue-100 rounded-2xl p-6
                         hover:border-blue-300 hover:shadow-xl hover:-translate-y-1
                         transition-all duration-250 no-underline block"
            >
              <span className="inline-block px-3 py-1 rounded-full text-[10px] font-bold
                               uppercase tracking-widest bg-orange-50 text-orange-500 mb-4">
                {tag}
              </span>
              <h4 className="font-display font-bold text-blue-950 text-lg mb-2
                             group-hover:text-blue-700 transition-colors duration-200">
                {name}
              </h4>
              <p className="text-gray-500 text-[13px] leading-relaxed mb-4">{desc}</p>
              <span className="inline-flex items-center gap-1 text-xs font-bold text-blue-800
                               group-hover:gap-2 transition-all duration-200">
                Explore <MdArrowOutward className="w-3 h-3" />
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
