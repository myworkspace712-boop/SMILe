import { MdArrowForward } from "react-icons/md";

export default function CTABanner() {
  return (
    <section className="relative py-20 overflow-hidden
                        bg-gradient-to-r from-orange-500 to-orange-600">

      {/* Decorative circles */}
      <div className="absolute -left-24 -top-24 w-80 h-80 rounded-full bg-white/8 pointer-events-none" />
      <div className="absolute -right-12 -bottom-20 w-64 h-64 rounded-full bg-black/8 pointer-events-none" />

      <div className="relative z-10 max-w-[1220px] mx-auto px-4 sm:px-6
                      flex flex-col sm:flex-row items-center justify-between gap-8">
        <div>
          <h2 className="font-display font-extrabold text-white text-3xl sm:text-4xl
                         leading-tight mb-3">
            Join the Movement!{" "}
            <span className="block sm:inline">Let's Grow Together</span>
          </h2>
          <p className="text-white/80 text-base max-w-lg leading-relaxed">
            Our network of 68,000 partners across Bharat forms the backbone and brains of SMILe.
            Fill out the form today and become a part of our family.
          </p>
        </div>

        <div className="flex flex-wrap gap-3 shrink-0">
          <a
            href="https://shreemaruti.com/contact-us/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full
                       bg-white text-orange-600 text-sm font-bold shadow-lg
                       hover:bg-orange-50 hover:scale-105 transition-all duration-200
                       no-underline"
          >
            Contact Us <MdArrowForward className="w-4 h-4" />
          </a>
          <a
            href="https://shreemaruti.com/channel-partners/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full
                       bg-white/15 hover:bg-white/25 border border-white/30
                       text-white text-sm font-semibold backdrop-blur-md
                       hover:scale-105 transition-all duration-200 no-underline"
          >
            Become a Partner
          </a>
        </div>
      </div>
    </section>
  );
}
