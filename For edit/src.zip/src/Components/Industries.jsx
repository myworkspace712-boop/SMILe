import { INDUSTRIES } from "./Data/siteData.js";

// Real industry images from shreemaruti.com
const INDUSTRY_IMAGES = {
  "Ecommerce":         "https://shreemaruti.com/wp-content/uploads/2023/08/industry-ecommerce.webp",
  "Gems & Jewelry":    "https://shreemaruti.com/wp-content/uploads/2023/08/industry-gems.webp",
  "Automobiles":       "https://shreemaruti.com/wp-content/uploads/2023/08/industry-auto.webp",
  "Agriculture":       "https://shreemaruti.com/wp-content/uploads/2023/08/industry-agriculture.webp",
  "Manufacturing":     "https://shreemaruti.com/wp-content/uploads/2023/08/industry-manufacturing.webp",
  "Food & Beverages":  "https://shreemaruti.com/wp-content/uploads/2023/08/industry-food.webp",
  "Fashion & Apparel": "https://shreemaruti.com/wp-content/uploads/2023/08/industry-fashion.webp",
  "Electronics":       "https://shreemaruti.com/wp-content/uploads/2023/08/industry-electronics.webp",
};

export default function Industries() {
  return (
    <section className="py-16 sm:py-24 bg-gradient-to-b from-blue-950 to-[#0f1540]">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6">

        <div className="text-center mb-10 sm:mb-12">
          <span className="inline-block px-4 py-1.5 rounded-full bg-white/10 text-white/80
                           text-xs font-bold tracking-widest uppercase mb-4 border border-white/20">
            Industries Served
          </span>
          <h2 className="font-display font-extrabold text-white text-2xl sm:text-4xl xl:text-5xl
                         leading-tight mb-4">
            Powering Every Sector
          </h2>
          <p className="text-white/55 text-sm sm:text-base max-w-xl mx-auto leading-relaxed">
            Regardless of your industry, commodity, or key markets, SMILe offers global
            and local logistics solutions that enable small and large businesses to grow.
          </p>
        </div>

        {/* 1-col xs → 2-col sm → 4-col lg */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {INDUSTRIES.map(({ icon, name, desc }) => (
            <div
              key={name}
              className="group bg-white/7 border border-white/12 rounded-2xl overflow-hidden
                         hover:bg-white/14 hover:-translate-y-1.5 hover:border-white/25
                         transition-all duration-300 cursor-pointer"
            >
              {/* Industry image — fades in on hover */}
              <img
                src={INDUSTRY_IMAGES[name]}
                alt={name}
                className="w-full h-28 sm:h-32 object-cover opacity-40
                           group-hover:opacity-60 transition-opacity duration-300"
                onError={(e) => e.currentTarget.style.display = "none"}
              />
              <div className="p-4 sm:p-6">
                <span className="text-2xl sm:text-3xl mb-3 block">{icon}</span>
                <h4 className="font-display font-bold text-white text-sm sm:text-[15px] mb-1.5">{name}</h4>
                <p className="text-white/50 text-xs leading-relaxed">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
