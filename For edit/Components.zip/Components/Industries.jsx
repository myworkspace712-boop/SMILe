import { INDUSTRIES } from "./Data/siteData.js";

export default function Industries() {
  return (
    <section className="py-24 bg-gradient-to-b from-blue-950 to-[#0f1540]">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6">

        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1.5 rounded-full bg-white/10 text-white/80
                           text-xs font-bold tracking-widest uppercase mb-4 border border-white/20">
            Industries Served
          </span>
          <h2 className="font-display font-extrabold text-white text-3xl sm:text-4xl xl:text-5xl
                         leading-tight mb-4">
            Powering Every Sector
          </h2>
          <p className="text-white/55 text-base max-w-xl mx-auto leading-relaxed">
            Regardless of your industry, commodity, or key markets, SMILe offers global
            and local logistics solutions that enable small and large businesses to grow.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {INDUSTRIES.map(({ icon, name, desc }) => (
            <div
              key={name}
              className="group bg-white/7 border border-white/12 rounded-2xl p-6
                         hover:bg-white/14 hover:-translate-y-1
                         transition-all duration-250 cursor-pointer"
            >
              <span className="text-3xl mb-4 block">{icon}</span>
              <h4 className="font-display font-bold text-white text-[15px] mb-1.5">{name}</h4>
              <p className="text-white/50 text-xs leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
