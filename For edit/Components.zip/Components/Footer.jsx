import { FOOTER_LINKS, SOCIAL_LINKS } from "./Data/siteData.js";

const SOCIAL_ICONS = {
  f:  "f",
  in: "in",
  li: "li",
  x:  "𝕏",
  yt: "▶",
};

export default function Footer() {
  return (
    <footer className="bg-zinc-900 text-white/70">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 pt-16 pb-8">

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">

          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-10 h-10 rounded-xl bg-blue-800 flex items-center justify-center">
                <span className="text-white font-display font-black text-base tracking-tighter">SM</span>
              </div>
              <div>
                <p className="font-display font-bold text-white text-base leading-tight">Shree Maruti</p>
                <p className="text-[11px] text-blue-400">Integrated Logistics Limited</p>
              </div>
            </div>
            <p className="text-[13.5px] text-white/50 leading-relaxed mb-5 max-w-xs">
              India's fastest express delivery, supply chain and logistics provider.
              Proudly Made in India, Delivered to the World.
            </p>

            {/* Social links */}
            <div className="flex gap-2">
              {SOCIAL_LINKS.map(({ icon, label, href }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="w-9 h-9 rounded-xl bg-white/8 border border-white/10
                             flex items-center justify-center text-[11px] font-bold
                             text-white/70 hover:bg-orange-500 hover:border-orange-500
                             hover:text-white transition-all duration-200 no-underline"
                >
                  {SOCIAL_ICONS[icon]}
                </a>
              ))}
            </div>

            {/* App store buttons */}
            <div className="flex gap-2 mt-4">
              {[
                { label: "Google Play", icon: "▶", sub: "Get it on" },
                { label: "App Store",   icon: "🍎", sub: "Download on the" },
              ].map(({ label, icon, sub }) => (
                <a
                  key={label}
                  href={label === "Google Play"
                    ? "https://play.google.com/store/apps/details?id=com.maruticourier.android"
                    : "https://apps.apple.com/in/app/shree-maruti-courier/id658296993"
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-3 py-2 rounded-xl
                             bg-white/8 border border-white/10
                             hover:bg-white/14 transition-all duration-200 no-underline"
                >
                  <span className="text-base">{icon}</span>
                  <div className="leading-tight">
                    <p className="text-[9px] text-white/40">{sub}</p>
                    <p className="text-[11px] font-semibold text-white">{label}</p>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(FOOTER_LINKS).map(([heading, links]) => (
            <div key={heading}>
              <h4 className="font-display font-bold text-white text-[11px] tracking-widest
                             uppercase mb-4">
                {heading}
              </h4>
              <ul className="flex flex-col gap-2">
                {links.map(({ label, href, badge }) => (
                  <li key={label}>
                    <a
                      href={href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[13px] text-white/50 hover:text-white
                                 transition-colors duration-200 no-underline
                                 inline-flex items-center gap-2"
                    >
                      {label}
                      {badge && (
                        <span className="text-[9px] font-bold bg-orange-500 text-white
                                         px-1.5 py-0.5 rounded-full">
                          {badge}
                        </span>
                      )}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Contact */}
          <div>
            <h4 className="font-display font-bold text-white text-[11px] tracking-widest
                           uppercase mb-4">
              Contact Us
            </h4>
            <ul className="flex flex-col gap-3 text-[13px] text-white/50">
              <li>
                <a href="mailto:info@shreemaruti.com"
                   className="hover:text-white transition-colors duration-200 no-underline">
                  info@shreemaruti.com
                </a>
              </li>
              <li>
                <a href="tel:+919712666666"
                   className="hover:text-white transition-colors duration-200 no-underline">
                  +91 9712 666 666
                </a>
              </li>
              <li className="text-white/35 text-[11px] leading-relaxed">
                52/A, Titanium, Opp. Prahaladnagar Garden,<br />
                100 Ft Road, Ahmedabad — 380015
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row
                        items-center justify-between gap-4">
          <p className="text-[12px] text-white/30">
            © {new Date().getFullYear()} Shree Maruti Integrated Logistics Limited. All rights reserved.
          </p>
          <div className="flex gap-4 text-[12px] text-white/30">
            {[
              { label: "Privacy Policy",  href: "https://shreemaruti.com/privacy-policy/" },
              { label: "Terms",           href: "https://shreemaruti.com/conditions-of-carriage/" },
              { label: "ONDC Disclosure", href: "https://shreemaruti.com/ondc-disclosure/" },
            ].map(({ label, href }) => (
              <a key={label} href={href} target="_blank" rel="noopener noreferrer"
                 className="hover:text-white transition-colors duration-200 no-underline">
                {label}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
