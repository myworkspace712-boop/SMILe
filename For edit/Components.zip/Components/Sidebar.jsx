import { useState, useRef, useEffect } from "react";
import { MdArrowDropDown } from "react-icons/md";
import { TbTruckDelivery } from "react-icons/tb";
import { NAV_ITEMS } from "./Data/siteData.js";

export default function Sidebar({ drawerOpen, setDrawerOpen }) {
  const [expanded, setExpanded] = useState(null);
  const drawerRef = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (drawerRef.current && !drawerRef.current.contains(e.target))
        setDrawerOpen(false);
    };
    document.addEventListener("click", handler);
    return () => document.removeEventListener("click", handler);
  }, [drawerOpen, setDrawerOpen]);

  if (!drawerOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-50 bg-black/25 backdrop-blur-md animate-backdrop-fade"
        onClick={() => setDrawerOpen(false)}
      />

      {/* Drawer panel */}
      <aside
        ref={drawerRef}
        className="fixed top-0 left-0 z-50 flex flex-col w-72 sm:w-80 h-screen
                   bg-white/75 backdrop-blur-xl shadow-2xl text-blue-950
                   animate-slide-in-left"
      >
        {/* Logo header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-white/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-800 flex items-center justify-center">
              <span className="text-white font-display font-black text-base tracking-tighter">SM</span>
            </div>
            <div className="leading-tight">
              <p className="font-display font-bold text-sm text-blue-950">Shree Maruti</p>
              <p className="text-[10px] text-blue-700 font-medium">Integrated Logistics</p>
            </div>
          </div>
          <button
            onClick={() => setDrawerOpen(false)}
            className="w-8 h-8 rounded-full flex items-center justify-center
                       hover:bg-blue-100/60 text-blue-800 text-lg font-bold
                       transition-all duration-200 cursor-pointer"
          >
            ×
          </button>
        </div>

        {/* Nav items */}
        <div className="flex flex-col gap-1.5 px-3 py-4 flex-1 overflow-y-auto">
          {NAV_ITEMS.map(({ key, label, href, children }) => {
            const hasChildren = children && children.length > 0;
            const isExpanded  = expanded === key;

            return (
              <div key={key}>
                <button
                  onClick={() => {
                    if (hasChildren) {
                      setExpanded((prev) => (prev === key ? null : key));
                    } else {
                      window.location.href = href;
                      setDrawerOpen(false);
                    }
                  }}
                  className={`flex items-center gap-3 w-full px-4 py-2.5 text-sm font-semibold
                              rounded-full transition-all duration-200 cursor-pointer text-left
                              border border-transparent
                              hover:border-white/30 hover:bg-white/50 hover:shadow-md
                              hover:backdrop-blur-md hover:scale-[1.01]
                              ${isExpanded
                                ? "bg-white/65 shadow-md text-blue-950 font-bold"
                                : "text-blue-900"
                              }`}
                >
                  <span className="flex-1">{label}</span>
                  {hasChildren && (
                    <MdArrowDropDown
                      className={`w-5 h-5 text-blue-900 transition-transform duration-300 ease-out
                                  ${isExpanded ? "rotate-180 text-blue-950" : ""}`}
                    />
                  )}
                </button>

                {/* Sub-items */}
                <div
                  className={`overflow-hidden transition-all duration-300 ease-out
                              ${isExpanded ? "max-h-96 opacity-100" : "max-h-0 opacity-0"}`}
                >
                  <div className="mt-1 mb-1 ml-4 flex flex-col gap-0.5">
                    {children?.map((child) => (
                      <a
                        key={child.label}
                        href={child.href}
                        target={child.href?.startsWith("http") ? "_blank" : undefined}
                        rel="noopener noreferrer"
                        onClick={() => { setDrawerOpen(false); setExpanded(null); }}
                        className="w-full text-left px-4 py-2 rounded-full text-xs font-semibold
                                   transition-all duration-200 cursor-pointer block
                                   border border-transparent
                                   hover:border-white/30 hover:bg-white/50 hover:shadow-md
                                   hover:backdrop-blur-md hover:scale-[1.01] text-blue-900
                                   no-underline"
                      >
                        {child.label}
                        {child.desc && (
                          <span className="block text-[10px] text-blue-600/70 font-normal mt-0.5">
                            {child.desc}
                          </span>
                        )}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="px-4 py-4 border-t border-white/40 flex flex-col gap-2">
          {/* Quick track */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const val = e.target.awb.value.trim();
              if (val) window.open(`https://shreemaruti.com/track-shipment/?awb=${encodeURIComponent(val)}`, "_blank");
            }}
            className="flex items-center gap-0 rounded-full overflow-hidden
                       border border-white/40 bg-blue-800/20 backdrop-blur-md"
          >
            <div className="flex items-center gap-1.5 px-3 py-2 flex-1">
              <TbTruckDelivery className="w-4 h-4 text-blue-800 shrink-0" />
              <input
                name="awb"
                placeholder="Track your shipment"
                className="bg-transparent border-none outline-none text-blue-950 text-xs
                           placeholder:text-blue-400 w-full"
              />
            </div>
            <button
              type="submit"
              className="bg-orange-500 text-white text-xs font-bold px-4 py-2
                         hover:bg-orange-600 transition-colors duration-200 cursor-pointer"
            >
              Go
            </button>
          </form>

          <a
            href="https://shreemaruti.com/ebookings/"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setDrawerOpen(false)}
            className="w-full text-center py-2.5 rounded-full bg-orange-500 text-white
                       text-sm font-bold hover:bg-orange-600 transition-all duration-200
                       hover:scale-[1.01] shadow-md no-underline block"
          >
            Ship Now
          </a>
        </div>

        {/* Footer note */}
        <p className="text-center text-[10px] text-blue-500 py-3">
          © {new Date().getFullYear()} Shree Maruti Integrated Logistics Limited
        </p>
      </aside>
    </>
  );
}
