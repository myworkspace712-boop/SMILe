import { STORIES } from "./Data/siteData.js";

export default function Stories() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6">

        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1.5 rounded-full bg-blue-50 text-blue-800
                           text-xs font-bold tracking-widest uppercase mb-4">
            Customer Stories
          </span>
          <h2 className="font-display font-extrabold text-blue-950 text-3xl sm:text-4xl xl:text-5xl
                         leading-tight mb-4">
            Stories That Make Us{" "}
            <span className="text-orange-500">Smile</span>
          </h2>
          <p className="text-gray-500 text-base max-w-xl mx-auto leading-relaxed">
            Real shipments. Real emotions. Real connections — from every corner of India to every corner of the world.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {STORIES.map(({ from, to, story, initials, name, sub }) => (
            <div
              key={name}
              className="group relative bg-blue-50/50 border border-blue-100 rounded-2xl p-6
                         hover:shadow-xl hover:-translate-y-1 hover:border-blue-200
                         transition-all duration-250"
            >
              {/* Big quote mark */}
              <span className="absolute top-4 right-5 font-display text-6xl text-blue-100
                               leading-none select-none">"</span>

              {/* Route pill */}
              <div className="flex items-center gap-2 mb-4 relative z-10">
                <span className="px-3 py-1 rounded-full bg-blue-800 text-white text-[11px] font-bold">
                  {from}
                </span>
                <span className="text-orange-500 font-bold text-sm">→</span>
                <span className="px-3 py-1 rounded-full bg-orange-500 text-white text-[11px] font-bold">
                  {to}
                </span>
              </div>

              <p className="text-gray-600 text-[13px] leading-relaxed mb-5 relative z-10">{story}</p>

              {/* Author */}
              <div className="flex items-center gap-2.5 relative z-10">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-800 to-orange-500
                                flex items-center justify-center text-white text-xs font-bold
                                font-display shrink-0">
                  {initials}
                </div>
                <div>
                  <p className="text-blue-950 text-xs font-bold">{name}</p>
                  <p className="text-gray-400 text-[10px]">{sub}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
