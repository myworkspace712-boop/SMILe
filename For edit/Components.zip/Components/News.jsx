import { MdArrowOutward } from "react-icons/md";
import { NEWS } from "./Data/siteData.js";

export default function News() {
  return (
    <section className="py-24 bg-blue-50/40">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6">

        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1.5 rounded-full bg-white text-blue-800
                           text-xs font-bold tracking-widest uppercase mb-4 border border-blue-100">
            In The Press
          </span>
          <h2 className="font-display font-extrabold text-blue-950 text-3xl sm:text-4xl xl:text-5xl
                         leading-tight mb-4">
            Latest News
          </h2>
          <p className="text-gray-500 text-base max-w-xl mx-auto leading-relaxed">
            Press releases, case studies and expert opinion from experts at Shree Maruti.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {NEWS.map(({ source, emoji, title, href }) => (
            <a
              key={title}
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="group bg-white border border-blue-100 rounded-2xl overflow-hidden
                         hover:shadow-xl hover:-translate-y-1 hover:border-blue-200
                         transition-all duration-250 no-underline block"
            >
              {/* Thumb */}
              <div className="h-40 bg-gradient-to-br from-blue-800 to-blue-600
                              flex items-center justify-center text-5xl relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-blue-950/60 to-transparent" />
                <span className="relative z-10">{emoji}</span>
                <span className="absolute bottom-3 left-4 z-10 px-3 py-1 rounded-full
                                 bg-white/15 backdrop-blur-md border border-white/25
                                 text-white text-[10px] font-bold tracking-wide">
                  {source}
                </span>
              </div>

              {/* Body */}
              <div className="p-5">
                <h5 className="font-display font-bold text-blue-950 text-sm leading-snug
                               group-hover:text-blue-700 transition-colors duration-200 mb-3">
                  {title}
                </h5>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold
                                 text-orange-500 group-hover:gap-2 transition-all duration-200">
                  Read more <MdArrowOutward className="w-3 h-3" />
                </span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
