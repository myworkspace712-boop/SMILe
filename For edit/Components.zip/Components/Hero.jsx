import { useState } from "react";
import { TbTruckDelivery } from "react-icons/tb";
import { MdArrowForward } from "react-icons/md";
import { STATS } from "./Data/siteData.js";

export default function Hero() {
  const [awb, setAwb]       = useState("");
  const [error, setError]   = useState("");

  const handleTrack = (e) => {
    e.preventDefault();
    if (!awb.trim()) { setError("Please enter a valid AWB number."); return; }
    setError("");
    window.open(`https://shreemaruti.com/track-shipment/?awb=${encodeURIComponent(awb)}`, "_blank");
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-[#0f1540] via-blue-950 to-[#1a0a2e] py-20 sm:py-28">

      {/* Background glow blobs */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute left-[-10%] top-[20%] w-96 h-96 rounded-full
                        bg-orange-500/10 blur-3xl" />
        <div className="absolute right-[5%] top-[10%] w-72 h-72 rounded-full
                        bg-blue-600/20 blur-3xl" />
      </div>

      <div className="relative z-10 max-w-[1220px] mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">

          {/* ── Left: headline + CTAs ────────────────── */}
          <div className="animate-hero">

            {/* Eyebrow badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full
                            bg-white/10 border border-white/20 mb-5">
              <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />
              <span className="text-[11px] font-bold text-white/90 tracking-widest uppercase">
                India's Leading Logistics Platform
              </span>
            </div>

            <h1 className="font-display font-extrabold text-white leading-[1.1]
                           text-4xl sm:text-5xl xl:text-6xl mb-5">
              Proudly Made in India,{" "}
              <span className="text-orange-500">Delivered to the World</span>
            </h1>

            <p className="text-white/65 text-base sm:text-lg leading-relaxed mb-8 max-w-lg">
              The SMILe platform orchestrates real-time order, inventory, and logistics
              management through tech-driven and scalable software — empowering brands
              to redefine fulfilment.
            </p>

            <div className="flex flex-wrap gap-3">
              <a
                href="https://shreemaruti.com/contact-us/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full
                           bg-orange-500 hover:bg-orange-600 text-white text-sm font-bold
                           shadow-lg shadow-orange-500/30 hover:shadow-orange-500/50
                           transition-all duration-200 hover:scale-105 no-underline"
              >
                Get in Touch <MdArrowForward className="w-4 h-4" />
              </a>
              <a
                href="https://shreemaruti.com/ebookings/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full
                           bg-white/10 hover:bg-white/18 border border-white/25
                           text-white text-sm font-semibold backdrop-blur-md
                           transition-all duration-200 hover:scale-105 no-underline"
              >
                Ship Now
              </a>
            </div>
          </div>

          {/* ── Right: track card + branch locator ───── */}
          <div className="animate-hero-delay flex flex-col gap-4">

            {/* Track card */}
            <div className="bg-white/10 backdrop-blur-xl border border-white/20
                            rounded-2xl p-6 shadow-xl">
              <h3 className="font-display font-bold text-white text-xl mb-1">
                Track Your Order
              </h3>
              <p className="text-white/55 text-sm mb-5">
                Enter your AWB number to get live shipment updates.
              </p>
              <form onSubmit={handleTrack} className="flex flex-col gap-3">
                <div className="flex items-center gap-0 rounded-full overflow-hidden
                                border border-white/25 bg-white/10 backdrop-blur-md">
                  <div className="flex items-center gap-2 px-4 py-3 flex-1">
                    <TbTruckDelivery className="w-4 h-4 text-white/70 shrink-0" />
                    <input
                      value={awb}
                      onChange={(e) => { setAwb(e.target.value); setError(""); }}
                      placeholder="Enter AWB Number"
                      className="bg-transparent border-none outline-none text-white
                                 text-sm placeholder:text-white/45 w-full"
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-orange-500 hover:bg-orange-600 transition-colors duration-200
                               text-white text-sm font-bold px-6 py-3 cursor-pointer"
                  >
                    Track
                  </button>
                </div>
                {error && <p className="text-red-400 text-xs px-1">{error}</p>}
              </form>
            </div>

            {/* Branch locator card */}
            <div className="bg-white/10 backdrop-blur-xl border border-white/20
                            rounded-2xl p-5 flex items-center justify-between gap-4">
              <div>
                <h4 className="font-display font-bold text-white text-base mb-1">
                  Branch Locator
                </h4>
                <p className="text-white/55 text-xs">
                  Find the nearest Shree Maruti outlet by city or pincode.
                </p>
              </div>
              <a
                href="https://shreemaruti.com/contact-us#store-locator"
                target="_blank"
                rel="noopener noreferrer"
                className="shrink-0 inline-flex items-center gap-1.5 px-4 py-2.5
                           rounded-full bg-white/15 hover:bg-white/25 border border-white/25
                           text-white text-xs font-semibold transition-all duration-200
                           hover:scale-105 no-underline whitespace-nowrap"
              >
                Find Locator <MdArrowForward className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>

        {/* ── Stats bar ──────────────────────────────── */}
        <div className="animate-hero-delay-2 mt-14 grid grid-cols-2 sm:grid-cols-4
                        divide-x divide-white/10 border border-white/10
                        rounded-2xl overflow-hidden bg-white/5 backdrop-blur-sm">
          {STATS.map(({ num, suffix, label }) => (
            <div
              key={label}
              className="px-6 py-6 flex flex-col gap-1 hover:bg-white/8
                         transition-all duration-200 text-center sm:text-left"
            >
              <span className="font-display font-extrabold text-4xl text-white leading-none">
                {num}<span className="text-orange-500">{suffix}</span>
              </span>
              <span className="text-sm text-white/50">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
