import { useState } from "react";
import { MdArrowForward } from "react-icons/md";
import { SERVICES_ENTERPRISE, SERVICES_INDIVIDUAL } from "./Data/siteData.js";

export default function Services() {
  const [tab, setTab] = useState("enterprise");
  const items = tab === "enterprise" ? SERVICES_ENTERPRISE : SERVICES_INDIVIDUAL;

  return (
    <section className="py-16 sm:py-24 bg-white">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6">

        <div className="text-center mb-10 sm:mb-12">
          <span className="inline-block px-4 py-1.5 rounded-full bg-blue-50 text-blue-800
                           text-xs font-bold tracking-widest uppercase mb-4">
            Bharat in Motion
          </span>
          <h2 className="font-display font-extrabold text-blue-950 text-2xl sm:text-4xl xl:text-5xl
                         leading-tight mb-4">
            What We Deliver
          </h2>
          <p className="text-gray-500 text-sm sm:text-base max-w-xl mx-auto leading-relaxed">
            SMILe ensures every piece of software, people, and service provider works
            towards fulfilling delivery promises — so brands can focus on what they do best.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex justify-center mb-8 sm:mb-10">
          <div className="flex gap-1.5 bg-blue-50 rounded-full p-1.5">
            {[
              { key: "enterprise", label: "For Enterprises" },
              { key: "individual", label: "For Individuals" },
            ].map(({ key, label }) => (
              <button
                key={key}
                onClick={() => setTab(key)}
                className={`px-4 sm:px-5 py-2 sm:py-2.5 rounded-full text-xs sm:text-sm font-semibold
                            transition-all duration-300 cursor-pointer
                            ${tab === key
                              ? "bg-white text-blue-950 shadow-md"
                              : "text-gray-500 hover:text-blue-800"
                            }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Cards */}
        <div className={`grid gap-4 sm:gap-5
                         ${tab === "enterprise"
                           ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"
                           : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"
                         }`}>
          {items.map(({ icon, title, desc }) => (
            <div
              key={title}
              className="group relative bg-white border border-blue-100 rounded-2xl p-5 sm:p-6
                         hover:border-blue-300 hover:shadow-xl hover:-translate-y-1.5
                         transition-all duration-300 cursor-pointer overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-50/60 to-transparent
                              opacity-0 group-hover:opacity-100 transition-opacity duration-300
                              rounded-2xl pointer-events-none" />

              <div className="relative z-10">
                <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-blue-800 to-blue-600
                                flex items-center justify-center text-xl sm:text-2xl mb-4 shadow-md
                                group-hover:scale-110 transition-transform duration-300">
                  {icon}
                </div>
                <h4 className="font-display font-bold text-blue-950 text-sm sm:text-base mb-2">{title}</h4>
                <p className="text-gray-500 text-[13px] leading-relaxed">{desc}</p>
                <span className="inline-flex items-center gap-1 mt-4 text-xs font-bold
                                 text-blue-800 group-hover:gap-2 transition-all duration-300">
                  Learn more <MdArrowForward className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
