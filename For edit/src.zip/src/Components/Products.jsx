import { MdArrowOutward } from "react-icons/md";
import { PRODUCTS } from "./Data/siteData.js";

// Real product logo images from shreemaruti.com
const PRODUCT_LOGOS = {
  "Innodel":       "https://shreemaruti.com/wp-content/uploads/2023/08/innodel-logo.png",
  "Innofulfill":   "https://shreemaruti.com/wp-content/uploads/2023/08/innofulfill-logo.png",
  "Coldverse":     "https://shreemaruti.com/wp-content/uploads/2023/08/coldverse-logo.png",
  "PALLET it":     "https://shreemaruti.com/wp-content/uploads/2023/08/palletit-logo.png",
  "International": "https://shreemaruti.com/wp-content/uploads/2023/08/international-logo.png",
  "CargoDham":     "https://shreemaruti.com/wp-content/uploads/2023/08/cargodham-logo.png",
  "Pinified":      "https://shreemaruti.com/wp-content/uploads/2023/08/pinified-logo.png",
  "Travel Free":   "https://shreemaruti.com/wp-content/uploads/2023/08/travelfree-logo.png",
};

export default function Products() {
  return (
    <section className="py-16 sm:py-24 bg-gradient-to-b from-blue-50/60 to-white">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6">

        <div className="text-center mb-10 sm:mb-12">
          <span className="inline-block px-4 py-1.5 rounded-full bg-orange-50 text-orange-600
                           text-xs font-bold tracking-widest uppercase mb-4">
            Our Products
          </span>
          <h2 className="font-display font-extrabold text-blue-950 text-2xl sm:text-4xl xl:text-5xl
                         leading-tight mb-4">
            From Humble Beginnings to{" "}
            <span className="text-orange-500">Global Excellence</span>
          </h2>
          <p className="text-gray-500 text-sm sm:text-base max-w-xl mx-auto leading-relaxed">
            SMILe has been built keeping users in mind. Our dedication to attention to
            detail ensures hassle-free logistics at all times.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
          {PRODUCTS.map(({ tag, name, desc }) => (
            <a
              key={name}
              href=""
              className="group bg-white border border-blue-100 rounded-2xl p-5 sm:p-6
                         hover:border-blue-300 hover:shadow-xl hover:-translate-y-1.5
                         transition-all duration-300 no-underline block"
            >
              {/* Product logo with tag fallback */}
              <div className="h-10 mb-4 flex items-center">
                <img
                  src={PRODUCT_LOGOS[name]}
                  alt={name}
                  className="h-full w-auto object-contain opacity-80
                             group-hover:opacity-100 transition-opacity duration-300"
                  onError={(e) => {
                    e.currentTarget.style.display = "none";
                    e.currentTarget.nextElementSibling.style.display = "inline-block";
                  }}
                />
                <span
                  className="hidden px-3 py-1 rounded-full text-[10px] font-bold
                             uppercase tracking-widest bg-orange-50 text-orange-500"
                >
                  {tag}
                </span>
              </div>

              <span className="inline-block px-3 py-1 rounded-full text-[10px] font-bold
                               uppercase tracking-widest bg-orange-50 text-orange-500 mb-3">
                {tag}
              </span>
              <h4 className="font-display font-bold text-blue-950 text-base sm:text-lg mb-2
                             group-hover:text-blue-700 transition-colors duration-300">
                {name}
              </h4>
              <p className="text-gray-500 text-[13px] leading-relaxed mb-4">{desc}</p>
              <span className="inline-flex items-center gap-1 text-xs font-bold text-blue-800
                               group-hover:gap-2 transition-all duration-300">
                Explore <MdArrowOutward className="w-3 h-3" />
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
